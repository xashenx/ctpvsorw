See TEP 125 for more information.
