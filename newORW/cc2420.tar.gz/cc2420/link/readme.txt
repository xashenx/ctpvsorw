PacketLink is used for link-layer retransmissions guided by your own
application requirements.  It will fail if it receives false-acknowledgements,
which is completely possible in 802.15.4.

See TEP 127 for more details.

